module IDiceStrategy;
