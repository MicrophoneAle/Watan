module FairDiceStrategy;
